from pathlib import Path
import re, os, subprocess
base = Path(__file__).resolve().parent
step, = (base/'project/runs/wokwi').glob('*-openroad-stapostpnr')
for path in sorted(step.glob('nom_*')):
    log = (path/'sta.log').read_text()
    def logged(kind):
        return re.findall(r"Reading " + kind + r"[^\n]*? at '([^']+)'", log)
    netlist, = logged("top-level netlist")
    text = Path(netlist).read_text()
    def driver(net):
        block, = [b for b in text.split(');') if re.search(r'\.Q\(\s*'+re.escape(net)+r'\s*\)',b)]
        return re.search(r'\bsg13cmos5l_\w+\s+(\w+)\s*\(',block).group(1)
    env = dict(CORNER=path.name, STA_LIBS='|'.join(logged("cell library")),
               NETLIST=netlist, SPEF=logged("top-level design parasitics")[0],
               SDC=logged("design constraints file")[0],
               ENV_TCL=str(next(path.glob('_env*.tcl'))),
               MISO_FF=driver('miso'), ACTIVE_FF=driver(r'\peripheral.active'))
    with (base/('io-'+path.name+'.log')).open('w') as out:
        subprocess.run(['docker','exec',*[arg for k,v in env.items() for arg in ['-e',k+'='+v]],
                        'chameleon-p1p2-precheck','sta','-no_splash','-exit',str(base/'io_paths.tcl')],
                       check=True,stdout=out,stderr=subprocess.STDOUT)
