# Additional reports on the flow's extracted netlist, RC and system-clock SDC.
set corner $::env(CORNER)
set_cmd_units -time ns -capacitance pF -current mA -voltage V -resistance kOhm -distance um
set sta_report_default_digits 6
define_corners $corner
foreach lib [split $::env(STA_LIBS) |] {read_liberty -corner $corner $lib}
read_verilog $::env(NETLIST)
link_design tt_um_forg_protocol_chameleon
source $::env(ENV_TCL)
read_sdc $::env(SDC)
read_spef -corner $corner $::env(SPEF)
foreach {name src dst} [list MISO $::env(MISO_FF) {uio_out[7]} DRIVE $::env(ACTIVE_FF) {uio_oe[7]}] {
  puts "BEGIN $name"
  report_checks -from [get_pins $src/CLK] -to [get_ports $dst] -path_delay max -corner $corner -format full_clock_expanded
}
foreach pin {{uio_in[1]} {uio_in[4]}} {
  puts "BEGIN DESELECT $pin"
  report_checks -from [get_ports $pin] -to [get_ports {uio_oe[7]}] -path_delay max -corner $corner
}
foreach delay {max min} {
  puts "BEGIN REGISTER $delay"
  report_checks -from [all_registers -clock_pins] -to [all_registers -data_pins] -corner $corner -path_delay $delay -format full_clock_expanded
}
