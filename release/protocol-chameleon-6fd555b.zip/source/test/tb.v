`default_nettype none
`timescale 1ns / 1ps

/* This testbench just instantiates the module and makes some convenient wires
   that can be driven / tested by the cocotb test.py.
*/
module tb ();

  // Dump the signals to a FST file. You can view it with gtkwave or surfer.
  initial begin
    $dumpfile("tb.fst");
    $dumpvars(0, tb);
    #1;
  end

  // Wire up the inputs and outputs:
  reg clk;
  reg rst_n;
  reg ena;
  reg [7:0] ui_in;
  reg [7:0] uio_in;
  reg [7:0] peer_oe;
  tri [7:0] pads;
  // Enable external pull-ups only for open-drain tests. Other tests observe Z.
  reg bus_pullups = 0;
  assign (pull1, pull0) pads[4] = bus_pullups ? 1'b1 : 1'bz;
  assign (pull1, pull0) pads[5] = bus_pullups ? 1'b1 : 1'bz;
  wire [7:0] uo_out;
  wire [7:0] uio_out;
  wire [7:0] uio_oe;

  // Both sides see the resolved pad: Z when released, X on opposing drives.
  genvar pin;
  generate
    for (pin = 0; pin < 8; pin = pin + 1) begin : pad_model
      assign pads[pin] = peer_oe[pin] ? uio_in[pin] : 1'bz;
      assign pads[pin] = uio_oe[pin] ? uio_out[pin] : 1'bz;
    end
  endgenerate

  tt_um_forg_protocol_chameleon user_project (
      .ui_in  (ui_in),    // Dedicated inputs
      .uo_out (uo_out),   // Dedicated outputs
      .uio_in (pads),     // IOs: resolved input path
      .uio_out(uio_out),  // IOs: Output path
      .uio_oe (uio_oe),   // IOs: Enable path (active high: 0=input, 1=output)
      .ena    (ena),      // enable - goes high when design is selected
      .clk    (clk),      // clock
      .rst_n  (rst_n)     // not reset
  );

endmodule
