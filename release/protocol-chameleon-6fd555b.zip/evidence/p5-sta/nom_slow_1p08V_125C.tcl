set_cmd_units -time ns -capacitance pF -current mA -voltage V -resistance kOhm -distance um
set sta_report_default_digits 6
define_corners nom_slow_1p08V_125C
read_liberty -corner nom_slow_1p08V_125C {/home/administrator/chameleon-m8-physical/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.ref/sg13cmos5l_stdcell/lib/sg13cmos5l_stdcell_slow_1p08V_125C.lib}
read_liberty -corner nom_slow_1p08V_125C {/home/administrator/chameleon-m8-physical/pdk/ciel/ihp-sg13/versions/89d42ee6d2fd9b50b86a1aada6fee6673c3e6008/ihp-sg13cmos5l/libs.ref/sg13cmos5l_io/lib/sg13cmos5l_io_slow_1p08V_3p0V_125C.lib}
read_verilog {/home/administrator/builds/chameleon-6fd555b/project/runs/wokwi/52-openroad-fillinsertion/tt_um_forg_protocol_chameleon.nl.v}
link_design tt_um_forg_protocol_chameleon
source {/home/administrator/builds/chameleon-6fd555b/project/runs/wokwi/55-openroad-stapostpnr/nom_slow_1p08V_125C/_env_ThreadPoolExecutor-4_1.tcl}
read_sdc {/nix/store/qs4izsy8n6gxz4zr31bjpwcq83nq2422-python3-3.13.13-env/lib/python3.13/site-packages/librelane/scripts/base.sdc}
read_spef -corner nom_slow_1p08V_125C {/home/administrator/builds/chameleon-6fd555b/project/runs/wokwi/54-openroad-rcx/nom/tt_um_forg_protocol_chameleon.nom.spef}
set verdict_CLK [get_pins {_17019_/CLK _17020_/CLK _17021_/CLK}]
set verdict_D [get_pins {_17019_/D _17020_/D _17021_/D}]
set source_CLK [get_pins {_17338_/CLK _17339_/CLK}]
set source_D [get_pins {_17338_/D _17339_/D}]
set previous_CLK [get_pins {_17479_/CLK _17480_/CLK _17481_/CLK}]
set previous_D [get_pins {_17479_/D _17480_/D _17481_/D}]
set older_CLK [get_pins {_17482_/CLK _17483_/CLK _17484_/CLK}]
set older_D [get_pins {_17482_/D _17483_/D _17484_/D}]
set edit_CLK [get_pins {_16141_/CLK _16142_/CLK _16143_/CLK _16144_/CLK _16145_/CLK _16146_/CLK _16147_/CLK _16148_/CLK _16149_/CLK _16150_/CLK _16151_/CLK _16152_/CLK _16153_/CLK _16154_/CLK _16155_/CLK _16156_/CLK _16274_/CLK _16275_/CLK _16276_/CLK _16277_/CLK _16278_/CLK _16279_/CLK _16280_/CLK _16281_/CLK _16486_/CLK _16487_/CLK _16488_/CLK _16489_/CLK _16490_/CLK _16491_/CLK _16492_/CLK _16493_/CLK}]
set edit_D [get_pins {_16141_/D _16142_/D _16143_/D _16144_/D _16145_/D _16146_/D _16147_/D _16148_/D _16149_/D _16150_/D _16151_/D _16152_/D _16153_/D _16154_/D _16155_/D _16156_/D _16274_/D _16275_/D _16276_/D _16277_/D _16278_/D _16279_/D _16280_/D _16281_/D _16486_/D _16487_/D _16488_/D _16489_/D _16490_/D _16491_/D _16492_/D _16493_/D}]
set bound_CLK [get_pins {_17385_/CLK _17386_/CLK _17387_/CLK _17388_/CLK _17389_/CLK _17390_/CLK _17391_/CLK _17392_/CLK}]
set bound_D [get_pins {_17385_/D _17386_/D _17387_/D _17388_/D _17389_/D _17390_/D _17391_/D _17392_/D}]
set valid_CLK [get_pins {_17393_/CLK}]
set valid_D [get_pins {_17393_/D}]
set live_CLK [get_pins {_17485_/CLK _17486_/CLK _17487_/CLK _17488_/CLK _17489_/CLK _17490_/CLK _17491_/CLK _17492_/CLK _17493_/CLK _17494_/CLK _17495_/CLK _17496_/CLK _17497_/CLK _17498_/CLK _17578_/CLK _17579_/CLK}]
set live_D [get_pins {_17485_/D _17486_/D _17487_/D _17488_/D _17489_/D _17490_/D _17491_/D _17492_/D _17493_/D _17494_/D _17495_/D _17496_/D _17497_/D _17498_/D _17578_/D _17579_/D}]
set log_CLK [get_pins {_16523_/CLK _16524_/CLK _16525_/CLK _16526_/CLK _16527_/CLK _16528_/CLK _16529_/CLK _16530_/CLK _16531_/CLK _16532_/CLK _16533_/CLK _16534_/CLK _16535_/CLK _16536_/CLK _16537_/CLK _16538_/CLK _16539_/CLK _16540_/CLK _16541_/CLK _16542_/CLK _16543_/CLK _16544_/CLK _16545_/CLK _16546_/CLK _16547_/CLK _16548_/CLK _16549_/CLK _16550_/CLK _16551_/CLK _16552_/CLK _16553_/CLK _16554_/CLK _16795_/CLK _16796_/CLK _16797_/CLK _16798_/CLK _16799_/CLK _16800_/CLK _16801_/CLK _16802_/CLK _16803_/CLK _16804_/CLK _16805_/CLK _16806_/CLK _16807_/CLK _16808_/CLK _16809_/CLK _16810_/CLK _16811_/CLK _16812_/CLK _16813_/CLK _16814_/CLK _16815_/CLK _16816_/CLK _16817_/CLK _16818_/CLK _16819_/CLK _16820_/CLK _16821_/CLK _16822_/CLK _16823_/CLK _16824_/CLK _16825_/CLK _16826_/CLK}]
set log_D [get_pins {_16523_/D _16524_/D _16525_/D _16526_/D _16527_/D _16528_/D _16529_/D _16530_/D _16531_/D _16532_/D _16533_/D _16534_/D _16535_/D _16536_/D _16537_/D _16538_/D _16539_/D _16540_/D _16541_/D _16542_/D _16543_/D _16544_/D _16545_/D _16546_/D _16547_/D _16548_/D _16549_/D _16550_/D _16551_/D _16552_/D _16553_/D _16554_/D _16795_/D _16796_/D _16797_/D _16798_/D _16799_/D _16800_/D _16801_/D _16802_/D _16803_/D _16804_/D _16805_/D _16806_/D _16807_/D _16808_/D _16809_/D _16810_/D _16811_/D _16812_/D _16813_/D _16814_/D _16815_/D _16816_/D _16817_/D _16818_/D _16819_/D _16820_/D _16821_/D _16822_/D _16823_/D _16824_/D _16825_/D _16826_/D}]
set frame_CLK [get_pins {_17154_/CLK _17155_/CLK _17156_/CLK _17157_/CLK _17158_/CLK _17159_/CLK _17160_/CLK _17161_/CLK _17162_/CLK _17163_/CLK _17164_/CLK _17165_/CLK _17166_/CLK _17167_/CLK _17168_/CLK _17169_/CLK}]
set frame_D [get_pins {_17154_/D _17155_/D _17156_/D _17157_/D _17158_/D _17159_/D _17160_/D _17161_/D _17162_/D _17163_/D _17164_/D _17165_/D _17166_/D _17167_/D _17168_/D _17169_/D}]
set branch_CLK [get_pins {_17123_/CLK _17124_/CLK _17125_/CLK}]
set branch_D [get_pins {_17123_/D _17124_/D _17125_/D}]
set shift_CLK [get_pins {_17141_/CLK _17142_/CLK _17143_/CLK _17144_/CLK _17145_/CLK _17146_/CLK _17147_/CLK _17148_/CLK}]
set shift_D [get_pins {_17141_/D _17142_/D _17143_/D _17144_/D _17145_/D _17146_/D _17147_/D _17148_/D}]
set miso_CLK [get_pins {_17122_/CLK}]
set miso_D [get_pins {_17122_/D}]
set all_registers_CLK [all_registers -clock_pins]
puts "BEGIN verdict live max"
report_checks -from $verdict_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN verdict live min"
report_checks -from $verdict_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN source live max"
report_checks -from $source_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN source live min"
report_checks -from $source_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN previous live max"
report_checks -from $previous_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN previous live min"
report_checks -from $previous_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN older live max"
report_checks -from $older_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN older live min"
report_checks -from $older_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN all_registers live max"
report_checks -from $all_registers_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN all_registers live min"
report_checks -from $all_registers_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN edit live max"
report_checks -from $edit_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN edit live min"
report_checks -from $edit_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN bound live max"
report_checks -from $bound_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN bound live min"
report_checks -from $bound_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN valid live max"
report_checks -from $valid_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN valid live min"
report_checks -from $valid_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN live live max"
report_checks -from $live_CLK -to $live_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN live live min"
report_checks -from $live_CLK -to $live_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN live log max"
report_checks -from $live_CLK -to $log_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN live log min"
report_checks -from $live_CLK -to $log_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN live frame max"
report_checks -from $live_CLK -to $frame_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN live frame min"
report_checks -from $live_CLK -to $frame_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN frame branch max"
report_checks -from $frame_CLK -to $branch_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN frame branch min"
report_checks -from $frame_CLK -to $branch_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN frame shift max"
report_checks -from $frame_CLK -to $shift_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN frame shift min"
report_checks -from $frame_CLK -to $shift_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN shift miso max"
report_checks -from $shift_CLK -to $miso_D -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN shift miso min"
report_checks -from $shift_CLK -to $miso_D -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN miso port max"
report_checks -from $miso_CLK -to [get_ports {uio_out[7]}] -path_delay max -corner nom_slow_1p08V_125C -format full_clock_expanded
puts "BEGIN miso port min"
report_checks -from $miso_CLK -to [get_ports {uio_out[7]}] -path_delay min -corner nom_slow_1p08V_125C -format full_clock_expanded
