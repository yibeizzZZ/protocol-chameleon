"""Bundle, then verify the official views, run evidence and exact source inputs."""
from pathlib import Path
from xml.etree import ElementTree as ET
import csv
import hashlib
import json
import re
import subprocess
import sys
import zipfile

build = Path(__file__).resolve().parent
project = build / "project"
run = project / "runs/wokwi"
submission = project / "tt_submission"
checks = project / "tt/precheck/reports"
top = "tt_um_forg_protocol_chameleon"
revision = "6fd555b7e008227d7bcdaa2b921525284ff5e062"
archive = Path(sys.argv[1])
def git(*args):
    return subprocess.check_output(["git", "-C", str(project), *args])

def verified_tests(xml, count):
    cases = ET.parse(xml).findall(".//testcase")
    assert len(cases) == count and not any(t.tag in ("error","failure","skipped") for row in cases for t in row), xml

assert json.loads((submission / "commit_id.json").read_text())["commit"] == revision
assert git("rev-parse", "HEAD").decode().strip() == revision
assert git("diff", "--name-only", "HEAD", "--", "src", "info.yaml", "test", "p1.py", "examples", "docs/info.md") == b""
verified_tests(build / "rtl.xml", 66)
verified_tests(build / "gl.xml", 66)
verified_tests(checks / "results.xml", 10)
assert "Ran 11 tests" in (build/"assembler.log").read_text() and (build/"assembler.log").read_text().strip().endswith("OK")
assert "Precheck passed" in (build/"precheck.log").read_text()
assert "Circuits match uniquely" in next(run.glob("*-netgen-lvs/reports/lvs.netgen.rpt")).read_text()
for extension in ("v", "gds", "lef"):
    file = f"{top}.{extension}"
    assert (submission / file).read_bytes() == (project / "precheck-views" / file).read_bytes()
assert (submission / f"{top}.v").read_bytes() == (project / "test/gate_level_netlist.v").read_bytes()
for sta_log in run.glob("*-openroad-stapostpnr/nom_*/sta.log"):
    content = sta_log.read_text()
    for resource, extension in (("top-level netlist", "v"), ("top-level design parasitics", "nom.spef")):
        match, = re.findall(r"Reading " + resource + r"[^\n]*? at '([^']+)'", content)
        assert Path(match).read_bytes() == (submission / f"{top}.{extension}").read_bytes(), match
metrics = json.loads((run / "final/metrics.json").read_text())
for key in ("magic__drc_error__count","design__lvs_error__count","route__drc_errors","route__antenna_violation__count",
            "timing__setup_vio__count","timing__hold_vio__count","design__max_slew_violation__count","design__max_cap_violation__count"):
    assert metrics[key] == 0, (key,metrics[key])
rpts = list(csv.DictReader((build/"p5-sta/paths.csv").open()))
assert len(rpts) == 3 * 15 * 2 and all(float(row["slack_ns"]) >= 0 for row in rpts)
# Independently compare the full lists of externally measured latency rows.
def latency(name):
    return re.findall(r'P5 edit [^\n]+', (build/name).read_text())
assert len(latency("rtl.log")) == 8 and latency("rtl.log") == latency("gl.log")
files = {str(f.relative_to(project)): f for f in sorted(submission.rglob("*")) if f.is_file()}
for name in ("rtl.log","gl.log","rtl.xml","gl.xml","assembler.log","harden.log","package.log",
             "precheck.log","config.log","pdf.log","check-docs.log","io_paths.py","io_paths.tcl",
             "report_p5_sta.py","package_evidence.py","release-base.sdc","sta-libraries.sha256"):
    files["evidence/"+name] = build / name
for f in sorted((build/"p5-sta").iterdir()):
    files["evidence/p5-sta/"+f.name] = f
for f in sorted(build.glob("io-*.log")):
    files["evidence/"+f.name] = f
files.update({
    "evidence/datasheet.pdf":project/"datasheet.pdf", "evidence/metrics.json":run/"final/metrics.json",
    "evidence/precheck.xml":checks/"results.xml", "evidence/precheck.md":checks/"results.md",
    "evidence/sta.rpt":next(run.glob("*-openroad-stapostpnr/summary.rpt")),
    "evidence/manufacturability.rpt":next(run.glob("*-misc-reportmanufacturability/manufacturability.rpt")),
    "evidence/lvs.netgen.rpt":next(run.glob("*-netgen-lvs/reports/lvs.netgen.rpt")),
    "evidence/drc.magic.rpt":next(run.glob("*-magic-drc/reports/drc.magic.rpt")),
    "evidence/slow-setup.rpt":next(run.glob("*-openroad-stapostpnr/nom_slow*/max.rpt")),
    "evidence/fast-hold.rpt":next(run.glob("*-openroad-stapostpnr/nom_fast*/min.rpt")),
})
files["evidence/synthesis-stat.json"] = next(run.glob("*-yosys-synthesis/reports/stat.json"))
for f in sorted(run.glob("*-openroad-stapostpnr/nom_*/checks.rpt")):
    files[f"evidence/sta/{f.parent.name}/checks.rpt"] = f
for f in sorted(run.glob("*-openroad-stapostpnr/nom_*/_env*.tcl")):
    files[f"evidence/sta/{f.parent.name}/{f.name}"] = f
for line in git("ls-files", "--", "src", "info.yaml", "test", "examples", "p1.py", "docs/info.md",
                "LICENSE", ".github/workflows/gds.yaml", ".github/workflows/test.yaml").decode().splitlines():
    assert git("show", f"{revision}:{line}") == (project/line).read_bytes(), line
    files["source/"+line] = project / line
provenance = {"design_commit":revision, "rtl_introduced_at":git("rev-parse","46af4d2").decode().strip(),
              "source_tree":git("rev-parse",f"{revision}:src").decode().strip(),
              "test_tree":git("rev-parse",f"{revision}:test").decode().strip(),
              "tt_support_tools":subprocess.check_output(["git","-C",str(project/"tt"),"rev-parse","HEAD"]).decode().strip(),
              "toolchain":json.loads((submission/"pdk.json").read_text()),
              "latency_measurements":latency("rtl.log")}
(build/"provenance.json").write_text(json.dumps(provenance,indent=2)+"\n")
files["evidence/provenance.json"] = build/"provenance.json"
sums = {}
archive.parent.mkdir(parents=True, exist_ok=True)
def write(z, name, data):
    info = zipfile.ZipInfo(name, (2026,11,21,0,0,0))
    info.external_attr = 0o100644 << 16
    z.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,compresslevel=8)
with zipfile.ZipFile(archive,"w") as z:
    for name,file in sorted(files.items()):
        data=file.read_bytes()
        sums[name]=hashlib.sha256(data).hexdigest()
        write(z,name,data)
    write(z,"SHA256SUMS","".join(f"{h}  {name}\n" for name,h in sums.items()).encode())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert all(hashlib.sha256(z.read(name)).hexdigest()==h for name,h in sums.items())
print("ZIP",archive,archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest())
print("GDS",sums[f"tt_submission/{top}.gds"])
print("Netlist",sums[f"tt_submission/{top}.v"])
